
let DATA=[],TOTAL=50,LIMIT=300000,idx=0,answers=[],started=0,lastQ=0,timer=null,ended=false,mode="today",session=[];
const $=x=>document.getElementById(x);
async function init(){DATA=await fetch("data.json").then(r=>r.json());renderHome()}
function norm(s){return(s||"").replace(/[ 　、。・,，.!！?？「」『』【】（）()［］\[\]〜～]/g,"").toLowerCase()}
function correct(a,m){a=norm(a);return !!a&&m.some(x=>{x=norm(x);return a===x||(a.length>=3&&x.length>=3&&(a.includes(x)||x.includes(a)))})}
function fmt(ms){let s=Math.max(0,Math.floor(ms/1000)),m=Math.floor(s/60),r=s%60;return String(m).padStart(2,"0")+":"+String(r).padStart(2,"0")}
function show(id){["home","quiz","result"].forEach(x=>$(x).classList.toggle("hide",x!==id))}
function getStats(){return JSON.parse(localStorage.getItem("target_stats")||"{}")}
function saveStats(){localStorage.setItem("target_stats",JSON.stringify(stats))}
let stats=getStats(); if(!stats.words)stats.words={}; if(!stats.tests)stats.tests=0; if(!stats.totalAnswered)stats.totalAnswered=0; if(!stats.totalCorrect)stats.totalCorrect=0;
function renderHome(){
  let h=JSON.parse(localStorage.getItem("target_history")||"[]");
  $("history").innerHTML=h.length?h.slice(0,7).map(x=>`${x.date}　<b>${x.good}/${TOTAL}</b>　${Math.round(x.good/TOTAL*100)}%　${x.mode}`).join("<br>"):"まだ記録がありません。";
  let acc=stats.totalAnswered?Math.round(stats.totalCorrect/stats.totalAnswered*100):0;
  let covered=Object.keys(stats.words).length;
  let weak=Object.values(stats.words).filter(w=>(w.wrong||0)+(w.slow||0)>0).length;
  $("dashboard").innerHTML=`累計テスト <b>${stats.tests}回</b>　｜　累計回答 <b>${stats.totalAnswered}</b>問　｜　累計正答率 <b>${acc}%</b><br>学習済み記録 <b>${covered}語</b>　｜　要復習候補 <b>${weak}語</b>　｜　収録範囲 <b>801–1500</b>`;
}
function buildSession(m){
  mode=m;
  let base=[...DATA];
  if(m==="review"){
    base.sort((a,b)=>(stats.words[b.no]?.wrong||0)-(stats.words[a.no]?.wrong||0));
  }else if(m==="weak"){
    base.sort((a,b)=>((stats.words[b.no]?.wrong||0)+(stats.words[b.no]?.slow||0))-((stats.words[a.no]?.wrong||0)+(stats.words[a.no]?.slow||0)));
  }else if(m==="random"){
    base.sort(()=>Math.random()-0.5);
  }else{
    // deterministic daily order, then shuffle within the day
    const seed=new Date().toISOString().slice(0,10).replaceAll("-","");
    let n=Number(seed); base.sort((a,b)=>((a.no*9301+n*49297)%233280)-((b.no*9301+n*49297)%233280));
  }
  session=base.slice(0,TOTAL);
}
function start(m){buildSession(m);idx=0;answers=[];ended=false;started=Date.now();lastQ=started;show("quiz");render();clearInterval(timer);timer=setInterval(hud,200)}
function render(){let d=session[idx];$("q").textContent=`${idx+1} / ${TOTAL}`;$("no").textContent=`No.${d.no}`;$("word").textContent=d.word;$("pos").textContent=d.pos;$("ans").value="";$("ans").focus();hud()}
function hud(){if(ended)return;let elapsed=Date.now()-started,rem=Math.max(0,LIMIT-elapsed);$("time").textContent=fmt(rem);$("bar").style.width=(idx/TOTAL*100)+"%";let ideal=Math.min(TOTAL,Math.floor(elapsed/60000*10)+1),done=answers.filter(Boolean).length;$("ideal").textContent=ideal;$("done").textContent=done;$("diff").textContent=done-ideal;$("forecast").textContent=elapsed?Math.min(TOTAL,Math.round(done*LIMIT/elapsed)):0;if(rem<=0)finish()}
function next(){if(ended)return;let d=session[idx],now=Date.now(),ms=now-lastQ,val=$("ans").value.trim();answers[idx]={answer:val,correct:correct(val,d.meanings),ms};if(idx===TOTAL-1){finish();return}idx++;lastQ=now;render()}
function finish(){
 if(ended)return;ended=true;clearInterval(timer);let elapsed=Math.min(LIMIT,Date.now()-started),done=answers.filter(Boolean).length,good=answers.filter(x=>x?.correct).length;
 $("score").textContent=`${good} / ${TOTAL}`;$("acc").textContent=`正答率 ${Math.round(good/TOTAL*100)}%`;
 $("ra").textContent=done;$("rs").textContent=TOTAL-done;$("re").textContent=fmt(elapsed);
 $("rav").textContent=done?(answers.reduce((s,x)=>s+(x?.ms||0),0)/done/1000).toFixed(1)+"秒":"—";
 $("rp").textContent=(elapsed?done/(elapsed/60000):0).toFixed(1)+"問/分";
 let bad=session.filter((d,i)=>answers[i]&&!answers[i].correct),slow=session.filter((d,i)=>answers[i]&&answers[i].ms>=8000);
 $("review").innerHTML=(bad.length?`<h3>📚 間違えた単語</h3>${bad.map(d=>`<div><b>No.${d.no} ${d.word}</b> — ${d.meanings.join("・")}</div>`).join("")}`:"<h3>🎉 不正解なし</h3>")+
 (slow.length?`<h3 style="margin-top:12px">⏱ 時間がかかった単語</h3>${slow.map(d=>`<div><b>${d.word}</b></div>`).join("")}`:"");
 $("tbody").innerHTML=session.map((d,i)=>{let a=answers[i];return `<tr class="${a&&!a.correct?'bad':''}"><td>${d.no}</td><td>${d.word}</td><td>${a?.answer||"—"}</td><td class="${a?.correct?'ok':'ng'}">${a?(a.correct?'○':'×'):'未回答'}</td><td>${a?(a.ms/1000).toFixed(1)+"秒":"—"}</td></tr>`}).join("");
 // Update persistent word-level stats
 session.forEach((d,i)=>{let a=answers[i];let w=stats.words[d.no]||{seen:0,correct:0,wrong:0,slow:0,totalMs:0};w.seen++;if(a?.correct)w.correct++;else w.wrong++;if(a&&a.ms>=8000)w.slow++;w.totalMs+=(a?.ms||0);stats.words[d.no]=w});
 stats.tests++;stats.totalAnswered+=done;stats.totalCorrect+=good;saveStats();
 let hist=JSON.parse(localStorage.getItem("target_history")||"[]");hist.unshift({date:new Date().toLocaleString("ja-JP"),good,done,mode,elapsed});localStorage.setItem("target_history",JSON.stringify(hist.slice(0,50)));
 show("result")
}
function saveStats(){localStorage.setItem("target_stats",JSON.stringify(stats))}
$("startToday").onclick=()=>start("today");$("startReview").onclick=()=>start("review");$("startWeak").onclick=()=>start("weak");$("startRandom").onclick=()=>start("random");
$("next").onclick=next;$("ans").addEventListener("keydown",e=>{if(e.key==="Enter"){e.preventDefault();next()}});
$("again").onclick=()=>start(mode);$("homeBtn").onclick=()=>{renderHome();show("home")};init();
if("serviceWorker"in navigator)navigator.serviceWorker.register("sw.js").catch(()=>{});
