
/* PHASE2: preserve existing stats while adding adaptive-review metadata */
(function(){
  try {
    const s=JSON.parse(localStorage.getItem('target_stats')||'{}');
    let changed=false;
    Object.keys(s).forEach(k=>{
      if(typeof s[k].reviewWeight!=='number'){s[k].reviewWeight=0;changed=true;}
      if(typeof s[k].streak!=='number'){s[k].streak=0;changed=true;}
    });
    if(changed)localStorage.setItem('target_stats',JSON.stringify(s));
  } catch(e){}
})();
